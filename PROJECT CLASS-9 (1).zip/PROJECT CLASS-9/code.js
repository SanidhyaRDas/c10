var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["68e0cb42-5e9b-4697-a432-df649db56cca","3cf4dc20-9bb1-4da5-ba7a-138db88b9242","caabbcd5-f8c1-4e04-9439-3f9834d98501","254a36f9-aa87-4e16-a30f-f2887896df56","644edf3c-7295-40a9-80e1-cd13a0c15456","9db653ea-26ca-49e9-95b2-1ed8081dc8b8"],"propsByKey":{"68e0cb42-5e9b-4697-a432-df649db56cca":{"name":"bg_landscape21_1","sourceUrl":"assets/api/v1/animation-library/gamelab/GTrVmut4s5PswM6hx254yCcDWLNhhmVk/category_backgrounds/bg_landscape21.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"GTrVmut4s5PswM6hx254yCcDWLNhhmVk","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/GTrVmut4s5PswM6hx254yCcDWLNhhmVk/category_backgrounds/bg_landscape21.png"},"3cf4dc20-9bb1-4da5-ba7a-138db88b9242":{"name":"enemyRed3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/S01FknIGIYlFWv..MNBfeuuvAjnR0YbD/category_vehicles/enemyRed3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"S01FknIGIYlFWv..MNBfeuuvAjnR0YbD","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/S01FknIGIYlFWv..MNBfeuuvAjnR0YbD/category_vehicles/enemyRed3.png"},"caabbcd5-f8c1-4e04-9439-3f9834d98501":{"name":"playerShip2_blue_1","sourceUrl":"assets/api/v1/animation-library/gamelab/o6MhvPFlxWIVVxxNBdRQQ9Cjv4HeJmYW/category_vehicles/playerShip2_blue.png","frameSize":{"x":112,"y":75},"frameCount":1,"looping":true,"frameDelay":2,"version":"o6MhvPFlxWIVVxxNBdRQQ9Cjv4HeJmYW","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":112,"y":75},"rootRelativePath":"assets/api/v1/animation-library/gamelab/o6MhvPFlxWIVVxxNBdRQQ9Cjv4HeJmYW/category_vehicles/playerShip2_blue.png"},"254a36f9-aa87-4e16-a30f-f2887896df56":{"name":"emoji_12_1","sourceUrl":"assets/api/v1/animation-library/gamelab/n0ZKL7BCk7DR.V7XB_SckQwGDUU4SyDZ/category_emoji/emoji_12.png","frameSize":{"x":300,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"n0ZKL7BCk7DR.V7XB_SckQwGDUU4SyDZ","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/n0ZKL7BCk7DR.V7XB_SckQwGDUU4SyDZ/category_emoji/emoji_12.png"},"644edf3c-7295-40a9-80e1-cd13a0c15456":{"name":"emoji_19_1","sourceUrl":"assets/api/v1/animation-library/gamelab/h_LF7PqnHba0BOlL85_9g6TgRHqzd_Lh/category_emoji/emoji_19.png","frameSize":{"x":300,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"h_LF7PqnHba0BOlL85_9g6TgRHqzd_Lh","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/h_LF7PqnHba0BOlL85_9g6TgRHqzd_Lh/category_emoji/emoji_19.png"},"9db653ea-26ca-49e9-95b2-1ed8081dc8b8":{"name":"emoji_18_1","sourceUrl":"assets/api/v1/animation-library/gamelab/3Ie77SBtMLM1Y2EaqoTH6vbcPmJ3kgku/category_emoji/emoji_18.png","frameSize":{"x":300,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"3Ie77SBtMLM1Y2EaqoTH6vbcPmJ3kgku","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3Ie77SBtMLM1Y2EaqoTH6vbcPmJ3kgku/category_emoji/emoji_18.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating boundaries
var leftboundary = createSprite(380, 120,10,100);
leftboundary.shapeColor = "green";
var rightboundary = createSprite(20, 120,10,100);
rightboundary.shapeColor = "green";
var leftboundary2 = createSprite(400, 200,10,400);
leftboundary2.shapeColor = "green";
var rightboundary2 = createSprite(0, 200,10,400);
rightboundary2.shapeColor = "green";
var topboundary = createSprite(205,5,400,10);
topboundary.shapeColor = "green";

//creating the player 
var player = createSprite(50, 300,20,20);
player.shapeColor = "red";
player.setAnimation("playerShip2_blue_1");
player.scale = 0.4;
var bullet = createSprite(50, 300,5,5);
bullet.shapeColor = "red";

//making enimies of the player
var spacecraft1 = createSprite(160, 40,20,20);
spacecraft1.shapeColor = "red";
spacecraft1.scale = 0.3;
spacecraft1.setAnimation("enemyRed3_1");
var spacecraft2 = createSprite(200, 40,20,20);
spacecraft2.shapeColor = "red";
spacecraft2.setAnimation("enemyRed3_1");
spacecraft2.scale = 0.3;
var spacecraft3 = createSprite(240, 40,20,20);
spacecraft3.shapeColor = "red";
spacecraft3.setAnimation("enemyRed3_1");
spacecraft3.scale = 0.3;
var spacecraft4 = createSprite(280, 40,20,20);
spacecraft4.shapeColor = "red";
spacecraft4.setAnimation("enemyRed3_1");
spacecraft4.scale = 0.3;
var spacecraft5 = createSprite(180, 80,20,20);
spacecraft5.shapeColor = "red";
spacecraft5.setAnimation("enemyRed3_1");
spacecraft5.scale = 0.3;
var spacecraft6 = createSprite(220, 80,20,20);
spacecraft6.shapeColor = "red";
spacecraft6.setAnimation("enemyRed3_1");
spacecraft6.scale = 0.3;
var spacecraft7 = createSprite(260, 80,20,20);
spacecraft7.shapeColor = "red";
spacecraft7.setAnimation("enemyRed3_1");
spacecraft7.scale = 0.3;

//creating score
var score = 0;

//creating bulley count
var score1 = 10;

var gameState = "serve";


function draw() {
//making background
background("green");

//displaying score
textSize(30);
text("Your Score-"+score, 200, 370);

//displayig bullet count
textSize(30);
text("Bullets Left-"+score1,10,370);

if (gameState=="serve") {
//display welcome text
textSize(30);
text("WELCOME!", 120, 115);
text("1.Press Enter to start",50,145);
text("2.Press arrow keys to",50,175);
text("move",60,205);
text("3.Press Shift to fire",50,235);

//making the shacecraft move
if (keyDown(ENTER)) {
  spacecraft1.velocityX = 3;
  spacecraft2.velocityX = 3;
  spacecraft3.velocityX = 3;
  spacecraft4.velocityX = 3;
  spacecraft5.velocityX = 3;
  spacecraft6.velocityX = 3;
  spacecraft7.velocityX = 3;
}
if (keyDown(ENTER)) {
  gameState="play";
}

}

if (gameState=="play") {
 //making player and spaceships bounce off from edges
spacecraft1.bounceOff(leftboundary2);
spacecraft1.bounceOff(rightboundary2);
spacecraft2.bounceOff(leftboundary2);
spacecraft2.bounceOff(rightboundary2);
spacecraft3.bounceOff(leftboundary2);
spacecraft3.bounceOff(rightboundary2);
spacecraft4.bounceOff(leftboundary2);
spacecraft4.bounceOff(rightboundary2);
spacecraft5.bounceOff(leftboundary);
spacecraft5.bounceOff(rightboundary);
spacecraft6.bounceOff(leftboundary);
spacecraft6.bounceOff(rightboundary);
spacecraft7.bounceOff(leftboundary);
spacecraft7.bounceOff(rightboundary);
player.bounceOff(leftboundary);
player.bounceOff(rightboundary);

//making the player move when keys are pressed
if (keyDown(LEFT_ARROW)) {
  player.x = player.x -4; 
}
if (keyDown(RIGHT_ARROW)) {
  player.x = player.x +4; 
}
if (keyDown(RIGHT_ARROW)) {
  bullet.x = player.x +4; 
}
if (keyDown(LEFT_ARROW)) {
  bullet.x = bullet.x -4; 
}

//making the player able to shoot
if (keyDown(SHIFT)) {
  bullet.velocityY=-15;
}
 if (keyDown(SHIFT)) {
  bullet.y=300;
  bullet.x=200;
  player.y=300;
  player.x=200;
   score1 = score1-1;
}

//making the box to be destroyed when bullet is touched
if (bullet.isTouching(spacecraft1)) {
  spacecraft1.destroy();
  score=score+1;
}
if (bullet.isTouching(spacecraft2)) {
  spacecraft2.destroy();
   score=score+1;
}
if (bullet.isTouching(spacecraft3)) {
  spacecraft3.destroy();
   score=score+1;
}
if (bullet.isTouching(spacecraft4)) {
  spacecraft4.destroy();
   score=score+1;
}
if (bullet.isTouching(spacecraft5)) {
  spacecraft5.destroy();
   score=score+1;
}
if (bullet.isTouching(spacecraft5)) {
  spacecraft5.destroy();
   score=score+1;
}
if (bullet.isTouching(spacecraft6)) {
  spacecraft6.destroy();
   score=score+1;
}
if (bullet.isTouching(spacecraft7)) {
  spacecraft7.destroy();
   score=score+1;
}

if (score==7||score1==0) {
  gameState="end";
}
}

if (gameState=="end") 
{
  textSize(30);
  text("GAME OVER!",50,55);
  text("Your feedback",50,105);
  //creating feedback obsticle
var feedback1 = createSprite(80, 200,80,40);
feedback1.shapeColor = "pink";
var feedback2 = createSprite(180,200,80,40);
feedback2.shapeColor = "pink";
var feedback3 = createSprite(280,200,80,40);
feedback3.shapeColor = "pink";

//creating feedback emojies
var emoji1 = createSprite(80, 200,80,40);
emoji1.shapeColor="yellow";
emoji1.setAnimation("emoji_12_1");
emoji1.scale = "0.1";
var emoji2 = createSprite(180,200,80,40);
emoji2.shapeColor="yellow";
emoji2.setAnimation("emoji_19_1");
emoji2.scale = "0.1";
var emoji3 = createSprite(280,200,80,40);
emoji3.shapeColor="yellow";
emoji3.setAnimation("emoji_18_1");
emoji3.scale = "0.1";
}



drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
